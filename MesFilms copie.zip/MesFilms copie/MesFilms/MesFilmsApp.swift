//
//  MesFilmsApp.swift
//  MesFilms
//
//  Created by David Mubilulu on 2026-07-13.
//

import SwiftUI

@main
struct MesFilmsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
