//
//  MovieListViewModel.swift
//  MesFilms
//
//  Created by David Mubilulu on 2026-07-13.
//

import Foundation
import SwiftUI
import Combine
// MARK: - ViewModel
// Contient toute la logique de gestion des données.
// Les vues ne modifient jamais le tableau directement :
// elles appellent toujours une méthode du ViewModel (exigence #6).
final class MovieListViewModel: ObservableObject {

    // @Published : les vues se redessinent automatiquement à chaque changement
    @Published var movies: [Movie] = Movie.sampleData

    // MARK: Suppression

    // Supprime un film précis (menu contextuel)
    func delete(_ movie: Movie) {
        movies.removeAll { $0.id == movie.id }
    }

    // Supprime via IndexSet (swipe natif de List)
    func delete(at offsets: IndexSet) {
        movies.remove(atOffsets: offsets)
    }

    // MARK: Réorganisation — Drag & Drop (exigence #3)
    func move(from source: IndexSet, to destination: Int) {
        movies.move(fromOffsets: source, toOffset: destination)
    }

    // MARK: Bascules d'état

    func toggleWatched(_ movie: Movie) {
        guard let i = movies.firstIndex(where: { $0.id == movie.id }) else { return }
        movies[i].isWatched.toggle()
    }

    func toggleFavorite(_ movie: Movie) {
        guard let i = movies.firstIndex(where: { $0.id == movie.id }) else { return }
        movies[i].isFavorite.toggle()
    }

    // MARK: Mise à jour depuis la vue détail

    func updateRating(for movie: Movie, rating: Int) {
        guard let i = movies.firstIndex(where: { $0.id == movie.id }) else { return }
        movies[i].rating = rating
    }

    func updateNotes(for movie: Movie, notes: String) {
        guard let i = movies.firstIndex(where: { $0.id == movie.id }) else { return }
        movies[i].notes = notes
    }

    // MARK: Ajout
    func add(_ movie: Movie) {
        movies.append(movie)
    }
}
