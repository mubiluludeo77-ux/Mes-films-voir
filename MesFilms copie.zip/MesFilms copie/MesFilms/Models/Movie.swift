//
//  Movie.swift
//  MesFilms
//
//  Created by David Mubilulu on 2026-07-13.
//

import Foundation

// MARK: - Modèle de données
// Représente un film dans la liste.
// Identifiable : requis pour List/ForEach
// Hashable : requis pour NavigationLink(value:)
// Codable : permet une future sauvegarde JSON
struct Movie: Identifiable, Hashable, Codable {
    let id: UUID
    var title: String
    var year: Int
    var genre: String
    var systemImage: String
    var rating: Int
    var isWatched: Bool
    var isFavorite: Bool
    var notes: String

    init(
        id: UUID = UUID(),
        title: String,
        year: Int,
        genre: String,
        systemImage: String,
        rating: Int = 0,
        isWatched: Bool = false,
        isFavorite: Bool = false,
        notes: String = ""
    ) {
        self.id = id
        self.title = title
        self.year = year
        self.genre = genre
        self.systemImage = systemImage
        self.rating = rating
        self.isWatched = isWatched
        self.isFavorite = isFavorite
        self.notes = notes
    }
}

// MARK: - Données d'exemple (source de données statique — exigence #1)
extension Movie {
    static let sampleData: [Movie] = [
        Movie(title: "Inception", year: 2010, genre: "Science-fiction",
              systemImage: "brain.head.profile", rating: 5,
              isWatched: true, isFavorite: true,
              notes: "Chef-d'œuvre de Nolan, à revoir."),
        Movie(title: "Le Voyage de Chihiro", year: 2001, genre: "Animation",
              systemImage: "leaf", rating: 5, isWatched: true),
        Movie(title: "Dune", year: 2021, genre: "Science-fiction",
              systemImage: "globe.americas", rating: 4),
        Movie(title: "Parasite", year: 2019, genre: "Drame",
              systemImage: "building.2", rating: 5,
              isWatched: true, isFavorite: true),
        Movie(title: "La La Land", year: 2016, genre: "Musical",
              systemImage: "music.note", rating: 4),
        Movie(title: "Interstellar", year: 2014, genre: "Science-fiction",
              systemImage: "sparkles", rating: 5),
        Movie(title: "Amélie Poulain", year: 2001, genre: "Comédie",
              systemImage: "heart", rating: 0),
        Movie(title: "Spider-Man: Spider-Verse", year: 2018, genre: "Animation",
              systemImage: "bolt", rating: 0)
    ]
}
