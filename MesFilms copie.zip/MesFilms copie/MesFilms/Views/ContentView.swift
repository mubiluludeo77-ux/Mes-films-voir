//
//  Content.swift
//  MesFilms
//
//  Created by David Mubilulu on 2026-07-13.
//

import SwiftUI

// MARK: - Vue principale
// Contient la NavigationStack et tous les gestes (exigences #3 et #4).
struct ContentView: View {

    // @StateObject : ContentView est propriétaire du ViewModel
    @StateObject private var viewModel = MovieListViewModel()
    @State private var showingAddMovie = false

    var body: some View {
        NavigationStack {
            List {
                ForEach(viewModel.movies) { movie in

                    // Navigation vers le détail (exigence #2)
                    NavigationLink(value: movie) {
                        MovieRowView(movie: movie)
                            // Geste double-tap : marque vu/non vu (exigence #3)
                            .onTapGesture(count: 2) {
                                withAnimation { viewModel.toggleWatched(movie) }
                            }
                    }

                    // Geste long-press : menu contextuel (exigences #3 et #4)
                    .contextMenu {
                        Button {
                            withAnimation { viewModel.toggleFavorite(movie) }
                        } label: {
                            Label(
                                movie.isFavorite ? "Retirer des favoris" : "Ajouter aux favoris",
                                systemImage: movie.isFavorite ? "star.slash" : "star"
                            )
                        }
                        Button {
                            withAnimation { viewModel.toggleWatched(movie) }
                        } label: {
                            Label(
                                movie.isWatched ? "Marquer non vu" : "Marquer comme vu",
                                systemImage: movie.isWatched ? "eye.slash" : "eye"
                            )
                        }
                        Button(role: .destructive) {
                            withAnimation { viewModel.delete(movie) }
                        } label: {
                            Label("Supprimer", systemImage: "trash")
                        }
                    }

                    // Geste swipe gauche : supprimer (exigence #3)
                    .swipeActions(edge: .trailing) {
                        Button(role: .destructive) {
                            withAnimation { viewModel.delete(movie) }
                        } label: {
                            Label("Supprimer", systemImage: "trash")
                        }
                    }

                    // Geste swipe droite : ajouter aux favoris (exigence #3)
                    .swipeActions(edge: .leading) {
                        Button {
                            withAnimation { viewModel.toggleFavorite(movie) }
                        } label: {
                            Label("Favori", systemImage: "star")
                        }
                        .tint(.yellow)
                    }
                }
                // Geste drag & drop pour réordonner (exigence #3)
                .onMove(perform: viewModel.move)
            }
            .listStyle(.insetGrouped)
            .navigationTitle("Mes films à voir")

            // Navigation déclarative par valeur
            .navigationDestination(for: Movie.self) { movie in
                MovieDetailView(movie: movie, viewModel: viewModel)
            }
            .toolbar {
                // Active le mode édition pour le drag & drop
                ToolbarItem(placement: .navigationBarLeading) {
                    EditButton()
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button {
                        showingAddMovie = true
                    } label: {
                        Image(systemName: "plus.circle.fill")
                    }
                }
            }
            // État vide
            .overlay {
                if viewModel.movies.isEmpty {
                    ContentUnavailableView(
                        "Aucun film",
                        systemImage: "film",
                        description: Text("Appuie sur + pour ajouter un film.")
                    )
                }
            }
            .sheet(isPresented: $showingAddMovie) {
                AddMovieView(viewModel: viewModel)
            }
        }
    }
}
