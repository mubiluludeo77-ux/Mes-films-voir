//
//  MovieDetail.swift
//  MesFilms
//
//  Created by David Mubilulu on 2026-07-13.
//

import SwiftUI

// MARK: - Vue de détail (exigence #2)
// Affichée lors de la sélection d'un film dans la liste.
struct MovieDetailView: View {
    let movie: Movie
    @ObservedObject var viewModel: MovieListViewModel

    @State private var isImageZoomed = false
    @State private var notesText: String = ""

    // Relit toujours le film depuis le ViewModel pour afficher
    // les changements en temps réel (note, vu, favori)
    private var currentMovie: Movie {
        viewModel.movies.first(where: { $0.id == movie.id }) ?? movie
    }

    var body: some View {
        ScrollView {
            VStack(spacing: 20) {

                // Affiche — geste double-tap pour zoomer (exigence #3)
                Image(systemName: currentMovie.systemImage)
                    .font(.system(size: isImageZoomed ? 150 : 80))
                    .foregroundStyle(.white)
                    .frame(width: isImageZoomed ? 220 : 140,
                           height: isImageZoomed ? 220 : 140)
                    .background(Color.accentColor)
                    .clipShape(RoundedRectangle(cornerRadius: 18))
                    .shadow(radius: 6)
                    .animation(.spring(response: 0.4, dampingFraction: 0.7),
                               value: isImageZoomed)
                    .onTapGesture(count: 2) {
                        isImageZoomed.toggle()
                    }

                VStack(spacing: 4) {
                    Text(currentMovie.title)
                        .font(.title2.bold())
                        .multilineTextAlignment(.center)
                    Text("\(currentMovie.genre) • \(String(currentMovie.year))")
                        .foregroundStyle(.secondary)
                }

                // Notation interactive : tap sur une étoile pour noter
                HStack(spacing: 8) {
                    ForEach(1...5, id: \.self) { star in
                        Image(systemName: star <= currentMovie.rating ? "star.fill" : "star")
                            .foregroundStyle(.yellow)
                            .onTapGesture {
                                withAnimation {
                                    viewModel.updateRating(for: currentMovie, rating: star)
                                }
                            }
                    }
                }
                .font(.title2)

                // Toggle vu / non vu
                Toggle(isOn: Binding(
                    get: { currentMovie.isWatched },
                    set: { _ in withAnimation { viewModel.toggleWatched(currentMovie) } }
                )) {
                    Label("Déjà vu", systemImage: "eye")
                }
                .padding(.horizontal)

                // Toggle favori
                Toggle(isOn: Binding(
                    get: { currentMovie.isFavorite },
                    set: { _ in withAnimation { viewModel.toggleFavorite(currentMovie) } }
                )) {
                    Label("Favori", systemImage: "star")
                }
                .padding(.horizontal)

                // Zone de notes personnelles
                VStack(alignment: .leading, spacing: 8) {
                    Text("Notes personnelles")
                        .font(.headline)
                    TextEditor(text: $notesText)
                        .frame(height: 120)
                        .padding(6)
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(Color.gray.opacity(0.3))
                        )
                        // Sauvegarde dans le ViewModel à chaque frappe
                        .onChange(of: notesText) { _, newValue in
                            viewModel.updateNotes(for: currentMovie, notes: newValue)
                        }
                }
                .padding(.horizontal)
            }
            .padding()
        }
        .navigationTitle(currentMovie.title)
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            // Initialise le champ avec les notes existantes
            notesText = currentMovie.notes
        }
    }
}
