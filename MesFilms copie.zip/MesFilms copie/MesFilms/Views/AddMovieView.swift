import SwiftUI

// MARK: - Formulaire d'ajout
// Présenté en sheet depuis ContentView.
// Permet d'enrichir la liste dynamiquement.
struct AddMovieView: View {
    @ObservedObject var viewModel: MovieListViewModel
    @Environment(\.dismiss) private var dismiss

    @State private var title = ""
    @State private var year = Calendar.current.component(.year, from: Date())
    @State private var genre = ""
    @State private var systemImage = "film"

    private let icons = ["film", "popcorn", "star", "theatermasks", "video", "tv"]

    var body: some View {
        NavigationStack {
            Form {
                Section("Informations") {
                    TextField("Titre", text: $title)
                    TextField("Genre", text: $genre)
                    Stepper("Année : \(String(year))", value: $year, in: 1900...2100)
                }
                Section("Icône (affiche)") {
                    Picker("Icône", selection: $systemImage) {
                        ForEach(icons, id: \.self) { icon in
                            Image(systemName: icon).tag(icon)
                        }
                    }
                    .pickerStyle(.segmented)
                }
            }
            .navigationTitle("Nouveau film")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Annuler") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Ajouter") {
                        viewModel.add(Movie(
                            title: title,
                            year: year,
                            genre: genre,
                            systemImage: systemImage
                        ))
                        dismiss()
                    }
                    // Bouton désactivé si les champs obligatoires sont vides
                    .disabled(title.isEmpty || genre.isEmpty)
                }
            }
        }
    }
}
