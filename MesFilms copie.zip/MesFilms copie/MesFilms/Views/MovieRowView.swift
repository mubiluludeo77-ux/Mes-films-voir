//
//  MovieRow.swift
//  MesFilms
//
//  Created by David Mubilulu on 2026-07-13.
//

import SwiftUI

// MARK: - Ligne de la liste
// Composant réutilisable isolé dans sa propre vue (exigence #6).
struct MovieRowView: View {
    let movie: Movie

    var body: some View {
        HStack(spacing: 12) {

            // Icône SF Symbols utilisée comme affiche
            Image(systemName: movie.systemImage)
                .font(.system(size: 26))
                .foregroundStyle(.white)
                .frame(width: 50, height: 50)
                .background(movie.isWatched ? Color.gray : Color.accentColor)
                .clipShape(RoundedRectangle(cornerRadius: 10))

            VStack(alignment: .leading, spacing: 4) {
                HStack(spacing: 4) {
                    Text(movie.title)
                        .font(.headline)
                        .lineLimit(1)
                    // Étoile jaune si favori
                    if movie.isFavorite {
                        Image(systemName: "star.fill")
                            .font(.caption2)
                            .foregroundStyle(.yellow)
                    }
                }

                Text("\(movie.genre) • \(String(movie.year))")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)

                // Affiche les étoiles seulement si le film a été noté
                if movie.rating > 0 {
                    HStack(spacing: 2) {
                        ForEach(1...5, id: \.self) { star in
                            Image(systemName: star <= movie.rating ? "star.fill" : "star")
                                .font(.system(size: 10))
                                .foregroundStyle(.yellow)
                        }
                    }
                }
            }

            Spacer()

            // Coche verte si le film a été vu
            if movie.isWatched {
                Image(systemName: "checkmark.circle.fill")
                    .foregroundStyle(.green)
            }
        }
        .padding(.vertical, 4)
    }
}
